const upload = require('./upload');
const uploadFile = require('./uploadFile');
const removeUploadFile = require('./removeUploadFile');

module.exports = { upload, uploadFile, removeUploadFile };
